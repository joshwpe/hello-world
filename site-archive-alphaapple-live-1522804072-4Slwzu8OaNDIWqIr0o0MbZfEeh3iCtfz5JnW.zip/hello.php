<?php
	echo "Hello y'all"; 
	//commenting stuff out

	/*This is commenting 
	out this entire section. 
	If you notice below there 
	is no closing tag for ?>. 
	This is not needed if 
	everything is the file is
	PHP. 
