<script type="text/javascript">  
document.write("Today is " + Date() );
</script>
