<?php
# Database Configuration
define( 'DB_NAME', 'wp_alphaapple' );
define( 'DB_USER', 'alphaapple' );
define( 'DB_PASSWORD', 'I6VRGVHluttiI1zh1gPz' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY',         'MjkOo]mW;LA8?gj&Zk0R>&GVa%jb:i54L18,]@Ai:8sJ+SCn_d|J9?|R4E0(&,+&');
define('SECURE_AUTH_KEY',  'QQtyU:Vy:%p[+_1+dcdxYB+1-(rU+E3BX77=?b yW-BCLMG>*7nBoD!(=C(^bf&i');
define('LOGGED_IN_KEY',    'FIyO06(G+fwK| -9R#:Br&b)_>-|k%JQA?|;Q+%|ng||JJG7LDXAXG}hK:Wy[Y/Z');
define('NONCE_KEY',        'xfxF8;i7lnA*_/a25/V#BSD+SH4F;%~F%8(~^a1<c?,ArUGu{d/9,yn`qF+^jGQ}');
define('AUTH_SALT',        'gQ+:J8^#C+b~4[pxn4*j=HXrf+x5CURP)G_wSEjVJ{qm3!X^[|E5c&PQ6&%o*#st');
define('SECURE_AUTH_SALT', '%8.Aj50RR%z0cC!~-*4:qO%NXkl~-Eu^5)-k=UQCf9)~AAZ|=~I,BU.yoUse9g#;');
define('LOGGED_IN_SALT',   '<+aX*~=cI7ihxwMO=I+-&T$$Tpdk|x|>mY~(-zwIybkE.$3[A{P3U*Kr%~:ILY-%');
define('NONCE_SALT',       'Jm2I`3+xD9fIW*a_aI`%;vzhV%%D#=-sT:/hy5GKn.V4|s5)z36v:_xs_J^4=w,@');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'alphaapple' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', 'f15fbd8c907577a0de4e9fca3e71c43161610e25' );

define( 'WPE_CLUSTER_ID', '120353' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_LBMASTER_IP', '' );

define( 'WPE_CDN_DISABLE_ALLOWED', false );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', 3 );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'thealphaapple.com', 1 => 'alphaapple.wpengine.com', 2 => 'www.thealphaapple.com', );

$wpe_varnish_servers=array ( 0 => 'pod-120353', );

$wpe_special_ips=array ( 0 => '104.198.248.156', );

$wpe_ec_servers=array ( );

$wpe_netdna_domains=array ( 0 =>  array ( 'match' => 'thealphaapple.com', 'secure' => true, 'dns_check' => '0', 'zone' => 'thealphaapple', ), );

$wpe_netdna_domains_secure=array ( 0 =>  array ( 'match' => 'thealphaapple.com', 'secure' => true, 'dns_check' => '0', 'zone' => 'thealphaapple', ), );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
